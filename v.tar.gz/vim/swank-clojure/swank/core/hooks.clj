(ns swank.core.hooks
  (:use (swank.util hooks)))

(defhook pre-reply-hook)